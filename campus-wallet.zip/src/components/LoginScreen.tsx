import React, { useState } from "react";
import { auth, db } from "../firebase";
import { signInWithEmailAndPassword, createUserWithEmailAndPassword } from "firebase/auth";
import { doc, getDoc, setDoc } from "firebase/firestore";
import { CampusUser, UserRole } from "../types";
import { Wallet, Loader2, Sparkles, LogIn, UserPlus } from "lucide-react";

interface LoginScreenProps {
  onLoginSuccess: (user: CampusUser) => void;
}

export default function LoginScreen({ onLoginSuccess }: LoginScreenProps) {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [isSignUp, setIsSignUp] = useState(false);
  const [role, setRole] = useState<UserRole>("student");
  const [displayName, setDisplayName] = useState("");
  const [studentId, setStudentId] = useState("");
  const [merchantName, setMerchantName] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const handleAuth = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError("");

    try {
      if (isSignUp) {
        if (!displayName) throw new Error("Full name is required");
        if (role === "student" && !studentId) throw new Error("Student ID is required");
        if (role === "merchant" && !merchantName) throw new Error("Merchant name is required");

        // Create firebase auth user
        const userCred = await createUserWithEmailAndPassword(auth, email, password);
        const uid = userCred.user.uid;

        // Create Firestore user document
        const initialBalance = role === "student" ? 100.00 : role === "merchant" ? 1000.00 : 0.00;
        const newUser: CampusUser = {
          uid,
          email,
          displayName,
          role,
          balance: initialBalance,
          createdAt: Date.now(),
          ...(role === "student" && { studentId }),
          ...(role === "merchant" && { merchantName }),
        };

        await setDoc(doc(db, "users", uid), newUser);
        onLoginSuccess(newUser);
      } else {
        // Sign in
        const userCred = await signInWithEmailAndPassword(auth, email, password);
        const uid = userCred.user.uid;

        // Fetch Firestore user doc
        const userDoc = await getDoc(doc(db, "users", uid));
        if (userDoc.exists()) {
          onLoginSuccess(userDoc.data() as CampusUser);
        } else {
          // Fallback if auth exists but no doc
          const fallbackUser: CampusUser = {
            uid,
            email,
            displayName: userCred.user.displayName || "Campus User",
            role: "student",
            balance: 50.00,
            createdAt: Date.now(),
            studentId: "S" + Math.floor(100000 + Math.random() * 900000),
          };
          await setDoc(doc(db, "users", uid), fallbackUser);
          onLoginSuccess(fallbackUser);
        }
      }
    } catch (err: any) {
      console.error(err);
      if (err.code === "auth/user-not-found" || err.code === "auth/wrong-password") {
        setError("Invalid email or password.");
      } else if (err.code === "auth/email-already-in-use") {
        setError("This email is already registered.");
      } else if (err.code === "auth/weak-password") {
        setError("Password should be at least 6 characters.");
      } else {
        setError(err.message || "An authentication error occurred.");
      }
    } finally {
      setLoading(false);
    }
  };

  // Quick Sign In for testing roles seamlessly
  const handleQuickSignIn = async (demoRole: UserRole) => {
    setLoading(true);
    setError("");

    let demoEmail = "";
    let demoName = "";
    let demoExtra = "";

    if (demoRole === "student") {
      demoEmail = "alex.mercer@campus.edu";
      demoName = "Alex Mercer";
      demoExtra = "STUDENT-4920";
    } else if (demoRole === "merchant") {
      demoEmail = "library.cafe@campus.edu";
      demoName = "Library Café Manager";
      demoExtra = "Library Café";
    } else {
      demoEmail = "admin.dean@campus.edu";
      demoName = "Dean Henderson";
      demoExtra = "Campus Admin";
    }

    const demoPassword = "campus123password";

    try {
      let userCred;
      try {
        userCred = await signInWithEmailAndPassword(auth, demoEmail, demoPassword);
      } catch (signInErr: any) {
        if (signInErr.code === "auth/user-not-found" || signInErr.code === "auth/invalid-credential") {
          // Create the user if they don't exist yet
          userCred = await createUserWithEmailAndPassword(auth, demoEmail, demoPassword);
        } else {
          throw signInErr;
        }
      }

      const uid = userCred.user.uid;
      const userDocRef = doc(db, "users", uid);
      const userDoc = await getDoc(userDocRef);

      let userData: CampusUser;
      if (!userDoc.exists()) {
        userData = {
          uid,
          email: demoEmail,
          displayName: demoName,
          role: demoRole,
          balance: demoRole === "student" ? 150.00 : demoRole === "merchant" ? 1500.00 : 0.00,
          createdAt: Date.now(),
          ...(demoRole === "student" && { studentId: demoExtra }),
          ...(demoRole === "merchant" && { merchantName: demoExtra }),
        };
        await setDoc(userDocRef, userData);
      } else {
        userData = userDoc.data() as CampusUser;
      }

      onLoginSuccess(userData);
    } catch (err: any) {
      console.error("Demo login error:", err);
      setError("Failed to initialize demo account. Please try manual register.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col justify-center py-12 px-4 sm:px-6 lg:px-8">
      <div className="sm:mx-auto sm:w-full sm:max-w-md text-center">
        <div className="inline-flex items-center justify-center h-16 w-16 rounded-full bg-blue-600 text-white shadow-md mb-4">
          <Wallet className="h-8 w-8" id="wallet-logo-icon" />
        </div>
        <h2 className="text-3xl font-extrabold text-blue-900 tracking-tight">
          BlueRidge Campus Wallet
        </h2>
        <p className="mt-2 text-sm text-slate-600 font-medium">
          Secure, instant smart transactions across the university campus.
        </p>
      </div>

      <div className="mt-8 sm:mx-auto sm:w-full sm:max-w-md">
        <div className="bg-white py-8 px-4 shadow-sm border border-slate-100 rounded-2xl sm:px-10">
          {error && (
            <div className="mb-4 bg-rose-50 border border-rose-100 text-rose-700 text-sm p-3 rounded-lg font-medium">
              {error}
            </div>
          )}

          <form className="space-y-4" onSubmit={handleAuth}>
            {isSignUp && (
              <>
                <div>
                  <label className="block text-sm font-semibold text-slate-700 mb-1">
                    Role Type
                  </label>
                  <div className="grid grid-cols-3 gap-2">
                    {(["student", "merchant", "admin"] as UserRole[]).map((r) => (
                      <button
                        key={r}
                        type="button"
                        onClick={() => setRole(r)}
                        className={`py-2 px-3 border text-xs font-bold rounded-lg capitalize transition-all ${
                          role === r
                            ? "bg-blue-600 text-white border-blue-600"
                            : "bg-white text-slate-700 border-slate-200 hover:bg-slate-50"
                        }`}
                      >
                        {r}
                      </button>
                    ))}
                  </div>
                </div>

                <div>
                  <label htmlFor="name" className="block text-sm font-semibold text-slate-700 mb-1">
                    {role === "merchant" ? "Contact Person Name" : "Full Name"}
                  </label>
                  <input
                    id="name"
                    type="text"
                    required
                    value={displayName}
                    onChange={(e) => setDisplayName(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-200 rounded-lg text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-600 focus:border-transparent text-sm"
                    placeholder="e.g. Alex Mercer"
                  />
                </div>

                {role === "student" && (
                  <div>
                    <label htmlFor="studentId" className="block text-sm font-semibold text-slate-700 mb-1">
                      Student ID Card Number
                    </label>
                    <input
                      id="studentId"
                      type="text"
                      required
                      value={studentId}
                      onChange={(e) => setStudentId(e.target.value)}
                      className="w-full px-3 py-2 border border-slate-200 rounded-lg text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-600 focus:border-transparent text-sm"
                      placeholder="e.g. STUDENT-4920"
                    />
                  </div>
                )}

                {role === "merchant" && (
                  <div>
                    <label htmlFor="merchantName" className="block text-sm font-semibold text-slate-700 mb-1">
                      Campus Outlet / Merchant Name
                    </label>
                    <input
                      id="merchantName"
                      type="text"
                      required
                      value={merchantName}
                      onChange={(e) => setMerchantName(e.target.value)}
                      className="w-full px-3 py-2 border border-slate-200 rounded-lg text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-600 focus:border-transparent text-sm"
                      placeholder="e.g. BlueRidge Library Café"
                    />
                  </div>
                )}
              </>
            )}

            <div>
              <label htmlFor="email" className="block text-sm font-semibold text-slate-700 mb-1">
                University Email Address
              </label>
              <input
                id="email"
                type="email"
                autoComplete="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full px-3 py-2 border border-slate-200 rounded-lg text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-600 focus:border-transparent text-sm"
                placeholder="you@campus.edu"
              />
            </div>

            <div>
              <label htmlFor="password" className="block text-sm font-semibold text-slate-700 mb-1">
                Password
              </label>
              <input
                id="password"
                type="password"
                autoComplete="current-password"
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full px-3 py-2 border border-slate-200 rounded-lg text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-600 focus:border-transparent text-sm"
                placeholder="••••••••"
              />
            </div>

            <button
              id="submit-auth-btn"
              type="submit"
              disabled={loading}
              className="w-full flex justify-center py-2.5 px-4 border border-transparent rounded-lg text-sm font-bold text-white bg-blue-600 hover:bg-blue-700 transition focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 disabled:opacity-50"
            >
              {loading ? (
                <Loader2 className="h-5 w-5 animate-spin text-white" />
              ) : isSignUp ? (
                <span className="flex items-center gap-1"><UserPlus className="h-4 w-4" /> Create Account</span>
              ) : (
                <span className="flex items-center gap-1"><LogIn className="h-4 w-4" /> Sign In</span>
              )}
            </button>
          </form>

          <div className="mt-4 flex items-center justify-between">
            <button
              onClick={() => {
                setIsSignUp(!isSignUp);
                setError("");
              }}
              className="text-xs font-semibold text-blue-600 hover:text-blue-800 transition"
            >
              {isSignUp ? "Already have an account? Sign In" : "Don't have an account? Sign Up"}
            </button>
          </div>

          <div className="mt-6 border-t border-slate-100 pt-6">
            <p className="text-xs font-bold text-slate-500 text-center uppercase tracking-wider mb-3 flex items-center justify-center gap-1">
              <Sparkles className="h-3.5 w-3.5 text-amber-500" /> Quick Demo Role Logins
            </p>
            <div className="grid grid-cols-3 gap-2">
              <button
                type="button"
                onClick={() => handleQuickSignIn("student")}
                className="bg-blue-50 hover:bg-blue-100 text-blue-800 border border-blue-200 py-2 px-1 rounded-lg text-xs font-bold transition text-center"
              >
                Student Roll
              </button>
              <button
                type="button"
                onClick={() => handleQuickSignIn("merchant")}
                className="bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border border-emerald-200 py-2 px-1 rounded-lg text-xs font-bold transition text-center"
              >
                Merchant Roll
              </button>
              <button
                type="button"
                onClick={() => handleQuickSignIn("admin")}
                className="bg-purple-50 hover:bg-purple-100 text-purple-800 border border-purple-200 py-2 px-1 rounded-lg text-xs font-bold transition text-center"
              >
                Dean Admin
              </button>
            </div>
            <p className="text-[10px] text-slate-400 text-center mt-2">
              Demo accounts auto-register real users in Firestore. Password is standard.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
