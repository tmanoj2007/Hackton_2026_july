import React, { useState, useEffect } from "react";
import { CampusUser, Transaction } from "../types";
import { db } from "../firebase";
import { collection, query, where, limit, orderBy, onSnapshot } from "firebase/firestore";
import { 
  Wallet, 
  ArrowUpRight, 
  QrCode, 
  History, 
  Lightbulb, 
  TrendingUp, 
  ShieldAlert, 
  CreditCard, 
  Send, 
  Activity,
  Coffee,
  BookOpen,
  Clapperboard,
  Waves,
  Sparkles,
  ShoppingBag
} from "lucide-react";

interface DashboardScreenProps {
  user: CampusUser;
  onNavigate: (page: string) => void;
}

export default function DashboardScreen({ user, onNavigate }: DashboardScreenProps) {
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [loading, setLoading] = useState(true);
  const [categoryStats, setCategoryStats] = useState<{ [cat: string]: number }>({});

  useEffect(() => {
    // Listen for recent transactions
    const txRef = collection(db, "transactions");
    const qTx = query(
      txRef,
      where("senderId", "==", user.uid),
      orderBy("timestamp", "desc"),
      limit(4)
    );
    const qRx = query(
      txRef,
      where("receiverId", "==", user.uid),
      orderBy("timestamp", "desc"),
      limit(4)
    );

    // Let's do a general user transaction query
    // Firestore doesn't support 'OR' queries easily across fields without complex composite indexes
    // So let's listen to all transactions for this user as sender or receiver by querying both and merging
    const unsubSender = onSnapshot(query(txRef, where("senderId", "==", user.uid), orderBy("timestamp", "desc"), limit(10)), (snapshot) => {
      const senderTxs = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }) as Transaction);
      
      const unsubReceiver = onSnapshot(query(txRef, where("receiverId", "==", user.uid), orderBy("timestamp", "desc"), limit(10)), (snapshotRx) => {
        const receiverTxs = snapshotRx.docs.map(doc => ({ id: doc.id, ...doc.data() }) as Transaction);
        
        // Merge and sort
        const merged = [...senderTxs, ...receiverTxs]
          .filter((v, i, a) => a.findIndex(t => t.id === v.id) === i) // Deduplicate
          .sort((a, b) => b.timestamp - a.timestamp)
          .slice(0, 5);

        setTransactions(merged);
        setLoading(false);

        // Calculate category stats for user's spend (where user is sender)
        const spends = [...senderTxs, ...receiverTxs].filter(tx => tx.senderId === user.uid && tx.type !== "add_money");
        const stats: { [cat: string]: number } = {};
        spends.forEach(s => {
          stats[s.category] = (stats[s.category] || 0) + s.amount;
        });
        setCategoryStats(stats);
      });

      return () => unsubReceiver();
    });

    return () => {
      unsubSender();
    };
  }, [user.uid]);

  const getCategoryIcon = (category: string) => {
    switch (category.toLowerCase()) {
      case "food":
      case "dining":
        return <Coffee className="h-4 w-4 text-amber-500" />;
      case "books":
      case "education":
        return <BookOpen className="h-4 w-4 text-blue-500" />;
      case "entertainment":
        return <Clapperboard className="h-4 w-4 text-purple-500" />;
      case "laundry":
      case "amenities":
        return <Waves className="h-4 w-4 text-cyan-500" />;
      case "deposits":
      case "add_money":
        return <ArrowUpRight className="h-4 w-4 text-emerald-500" />;
      default:
        return <ShoppingBag className="h-4 w-4 text-slate-500" />;
    }
  };

  return (
    <div className="space-y-6">
      {/* Welcome Banner */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 bg-gradient-to-r from-blue-700 to-blue-900 text-white p-6 rounded-2xl shadow-sm border border-blue-800">
        <div>
          <h2 className="text-2xl font-bold tracking-tight">
            Welcome back, {user.displayName}!
          </h2>
          <p className="text-blue-100 text-sm mt-1">
            {user.role === "student" 
              ? `Student ID: ${user.studentId || "N/A"} | BlueRidge State University`
              : user.role === "merchant"
                ? `Merchant: ${user.merchantName || "Campus Merchant"} | Partner Portal`
                : "System Administrator | Operations Panel"
            }
          </p>
        </div>
        <div className="flex items-center gap-2 bg-white/10 px-4 py-2 rounded-xl backdrop-blur-sm border border-white/10">
          <Activity className="h-4 w-4 text-sky-300 animate-pulse" />
          <span className="text-xs font-bold uppercase tracking-wider">Wallet Active</span>
        </div>
      </div>

      {/* Stats Cards Section */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* Wallet Balance Card */}
        <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100 flex flex-col justify-between h-48 relative overflow-hidden">
          <div className="absolute right-0 top-0 h-24 w-24 bg-blue-50 rounded-full -mr-8 -mt-8 -z-10"></div>
          <div>
            <span className="text-xs font-bold text-slate-400 uppercase tracking-wider block">Wallet Balance</span>
            <span className="text-3xl font-extrabold text-blue-900 mt-2 block">
              ${user.balance.toFixed(2)}
            </span>
          </div>
          <div className="flex gap-2">
            <button
              onClick={() => onNavigate("add-money")}
              className="flex-1 inline-flex items-center justify-center gap-1.5 py-2 px-3 bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs rounded-xl shadow-sm transition"
            >
              <CreditCard className="h-3.5 w-3.5" /> Add Money
            </button>
            <button
              onClick={() => onNavigate("qr-payment")}
              className="flex-1 inline-flex items-center justify-center gap-1.5 py-2 px-3 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs rounded-xl transition"
            >
              <QrCode className="h-3.5 w-3.5" /> Pay QR
            </button>
          </div>
        </div>

        {/* Quick Insights Cards */}
        {user.role === "student" ? (
          <>
            <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100 flex flex-col justify-between h-48">
              <div>
                <span className="text-xs font-bold text-slate-400 uppercase tracking-wider block">Top Spending Cat</span>
                {Object.keys(categoryStats).length > 0 ? (
                  <div className="mt-2 flex items-center gap-2">
                    <div className="p-2.5 rounded-xl bg-amber-50 border border-amber-100">
                      {getCategoryIcon(Object.keys(categoryStats)[0])}
                    </div>
                    <div>
                      <span className="text-lg font-bold text-slate-800 block capitalize">
                        {Object.keys(categoryStats)[0]}
                      </span>
                      <span className="text-xs font-semibold text-slate-400">
                        Total: ${categoryStats[Object.keys(categoryStats)[0]].toFixed(2)}
                      </span>
                    </div>
                  </div>
                ) : (
                  <div className="mt-2 text-sm font-semibold text-slate-500">
                    No spends logged yet.
                  </div>
                )}
              </div>
              <button
                onClick={() => onNavigate("ai-tips")}
                className="inline-flex items-center gap-1 text-xs font-bold text-blue-600 hover:text-blue-800 transition"
              >
                <Sparkles className="h-3.5 w-3.5 text-amber-500" /> Ask AI Spending Tips
              </button>
            </div>

            <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100 flex flex-col justify-between h-48">
              <div>
                <span className="text-xs font-bold text-slate-400 uppercase tracking-wider block">Savings Challenger</span>
                <span className="text-sm font-bold text-slate-800 mt-2 block">
                  Weekly Lunch-Box Challenge
                </span>
                <p className="text-xs font-medium text-slate-500 mt-1 line-clamp-2">
                  Bring lunch on Wednesday and Friday. Estimated savings of $15 per week.
                </p>
              </div>
              <div className="w-full bg-slate-100 rounded-full h-1.5 mt-2">
                <div className="bg-blue-600 h-1.5 rounded-full" style={{ width: "65%" }}></div>
              </div>
            </div>
          </>
        ) : user.role === "merchant" ? (
          <>
            <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100 flex flex-col justify-between h-48">
              <div>
                <span className="text-xs font-bold text-slate-400 uppercase tracking-wider block">Outlet Status</span>
                <div className="mt-2 flex items-center gap-2">
                  <div className="h-3 w-3 rounded-full bg-emerald-500 animate-pulse"></div>
                  <span className="text-lg font-bold text-slate-800">Accepting Payments</span>
                </div>
                <p className="text-xs font-medium text-slate-500 mt-1">
                  Ready to process instant checkouts via customer QR codes.
                </p>
              </div>
              <button
                onClick={() => onNavigate("qr-payment")}
                className="w-full text-center py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl transition"
              >
                Scan Customer QR
              </button>
            </div>

            <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100 flex flex-col justify-between h-48">
              <div>
                <span className="text-xs font-bold text-slate-400 uppercase tracking-wider block">Total Transactions</span>
                <span className="text-2xl font-extrabold text-slate-800 mt-2 block">
                  {transactions.filter(t => t.receiverId === user.uid).length} sales
                </span>
                <p className="text-xs font-medium text-slate-500 mt-1">
                  Keep track of all campus purchases processed today.
                </p>
              </div>
              <button
                onClick={() => onNavigate("history")}
                className="inline-flex items-center gap-1 text-xs font-bold text-blue-600 hover:text-blue-800 transition"
              >
                <History className="h-3.5 w-3.5" /> Full Sales History
              </button>
            </div>
          </>
        ) : (
          <>
            <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100 flex flex-col justify-between h-48">
              <div>
                <span className="text-xs font-bold text-slate-400 uppercase tracking-wider block">System Status</span>
                <div className="mt-2 flex items-center gap-2">
                  <div className="h-3 w-3 rounded-full bg-emerald-500 animate-pulse"></div>
                  <span className="text-lg font-bold text-slate-800">Operational</span>
                </div>
                <p className="text-xs font-medium text-slate-500 mt-1">
                  Cloud network latency is excellent (12ms). All transaction APIs active.
                </p>
              </div>
              <button
                onClick={() => onNavigate("admin")}
                className="w-full text-center py-2 bg-purple-600 hover:bg-purple-700 text-white font-bold text-xs rounded-xl transition"
              >
                System Control Panel
              </button>
            </div>

            <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100 flex flex-col justify-between h-48">
              <div>
                <span className="text-xs font-bold text-slate-400 uppercase tracking-wider block">System Treasury</span>
                <span className="text-2xl font-extrabold text-slate-800 mt-2 block">
                  Active Security Logs
                </span>
                <p className="text-xs font-medium text-slate-500 mt-1">
                  Real-time monitoring of campus-wide balance transfers.
                </p>
              </div>
              <button
                onClick={() => onNavigate("admin")}
                className="inline-flex items-center gap-1 text-xs font-bold text-purple-600 hover:text-purple-800 transition"
              >
                <ShieldAlert className="h-3.5 w-3.5" /> Monitor Treasury
              </button>
            </div>
          </>
        )}
      </div>

      {/* Main Grid: Recent Transactions & Campus Map/Quick Transfer */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left Columns: Recent Transactions */}
        <div className="lg:col-span-2 bg-white p-6 rounded-2xl shadow-sm border border-slate-100">
          <div className="flex justify-between items-center mb-4">
            <h3 className="text-base font-bold text-slate-800">Recent Transactions</h3>
            <button
              onClick={() => onNavigate("history")}
              className="text-xs font-bold text-blue-600 hover:text-blue-800 transition"
            >
              See All
            </button>
          </div>

          {loading ? (
            <div className="py-8 text-center text-slate-400 text-sm font-semibold">
              Loading transactions...
            </div>
          ) : transactions.length === 0 ? (
            <div className="py-12 text-center">
              <History className="h-10 w-10 text-slate-300 mx-auto mb-2" />
              <p className="text-sm font-semibold text-slate-500">No transactions yet</p>
              <p className="text-xs text-slate-400 mt-1">
                Your payments and deposit history will appear here.
              </p>
            </div>
          ) : (
            <div className="divide-y divide-slate-100">
              {transactions.map((tx) => {
                const isDebit = tx.senderId === user.uid;
                const formattedAmt = `${isDebit ? "-" : "+"}$${tx.amount.toFixed(2)}`;
                return (
                  <div key={tx.id} className="py-3.5 flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div className="p-2 bg-slate-50 rounded-xl border border-slate-100">
                        {getCategoryIcon(tx.category)}
                      </div>
                      <div>
                        <span className="text-sm font-bold text-slate-800 block">
                          {isDebit ? tx.receiverName : tx.senderName}
                        </span>
                        <span className="text-[11px] font-semibold text-slate-400 block mt-0.5">
                          {new Date(tx.timestamp).toLocaleString()} • {tx.category}
                        </span>
                      </div>
                    </div>
                    <div className="text-right">
                      <span className={`text-sm font-bold block ${isDebit ? "text-slate-800" : "text-emerald-600"}`}>
                        {formattedAmt}
                      </span>
                      <span className="text-[10px] font-medium text-slate-400 block mt-0.5 max-w-[120px] truncate">
                        {tx.description}
                      </span>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>

        {/* Right Column: Dynamic Campus Merch/Ad Card */}
        <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100 flex flex-col justify-between">
          <div>
            <h3 className="text-base font-bold text-slate-800 mb-2">Campus Merchant Outlets</h3>
            <p className="text-xs text-slate-500 mb-4">
              Use your campus wallet balance at these affiliated student stations for 10% cash-backs.
            </p>
            
            <div className="space-y-3">
              <div className="p-3 bg-blue-50/50 hover:bg-blue-50 border border-blue-100/50 rounded-xl transition flex items-center justify-between">
                <div>
                  <span className="text-xs font-bold text-blue-950 block">BlueRidge Library Café</span>
                  <span className="text-[10px] text-blue-700 font-semibold">10% Student Rebate • Library 1st Fl</span>
                </div>
                <Coffee className="h-4 w-4 text-blue-600" />
              </div>

              <div className="p-3 bg-purple-50/50 hover:bg-purple-50 border border-purple-100/50 rounded-xl transition flex items-center justify-between">
                <div>
                  <span className="text-xs font-bold text-purple-950 block">Varsity Book & Stationery</span>
                  <span className="text-[10px] text-purple-700 font-semibold">Textbooks & Tech • Student Union</span>
                </div>
                <BookOpen className="h-4 w-4 text-purple-600" />
              </div>

              <div className="p-3 bg-cyan-50/50 hover:bg-cyan-50 border border-cyan-100/50 rounded-xl transition flex items-center justify-between">
                <div>
                  <span className="text-xs font-bold text-cyan-950 block">Campus Laundry & Lockers</span>
                  <span className="text-[10px] text-cyan-700 font-semibold">Coinless Wash • Residence Hall</span>
                </div>
                <Waves className="h-4 w-4 text-cyan-600" />
              </div>
            </div>
          </div>

          <div className="mt-4 pt-4 border-t border-slate-100 bg-slate-50 p-3 rounded-xl border border-slate-100">
            <span className="text-xs font-bold text-slate-700 block mb-1">Peer Money Transfer</span>
            <p className="text-[10px] text-slate-500 mb-2">Transfer money instantly to campus friends via their QR Code.</p>
            <button
              onClick={() => onNavigate("qr-payment")}
              className="w-full py-1.5 bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs rounded-lg transition text-center flex items-center justify-center gap-1"
            >
              <Send className="h-3 w-3" /> Start Peer Pay
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
