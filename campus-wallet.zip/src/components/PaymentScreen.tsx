import React, { useState, useEffect } from "react";
import { CampusUser, Transaction } from "../types";
import { db } from "../firebase";
import { doc, getDoc, collection, addDoc, runTransaction, getDocs, query, where } from "firebase/firestore";
import { 
  ArrowLeft, 
  QrCode, 
  Send, 
  Loader2, 
  CheckCircle2, 
  Search, 
  Coffee, 
  BookOpen, 
  Waves, 
  User,
  AlertTriangle
} from "lucide-react";

interface PaymentScreenProps {
  user: CampusUser;
  onRefreshUser: (updatedUser: Partial<CampusUser>) => void;
  onNavigate: (page: string) => void;
}

export default function PaymentScreen({ user, onRefreshUser, onNavigate }: PaymentScreenProps) {
  const [activeTab, setActiveTab] = useState<"show_qr" | "pay_peer_merchant">(
    user.role === "merchant" ? "pay_peer_merchant" : "show_qr"
  );
  const [targetId, setTargetId] = useState("");
  const [targetName, setTargetName] = useState("");
  const [amount, setAmount] = useState("");
  const [category, setCategory] = useState("Food");
  const [description, setDescription] = useState("");
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);
  const [error, setError] = useState("");
  const [recentRecipients, setRecentRecipients] = useState<{ id: string; name: string; role: string; email: string }[]>([]);

  // Pre-seed some default merchant users to easily pay them
  const defaultMerchants = [
    { id: "MOCK_CAFE", name: "BlueRidge Library Café", role: "merchant", email: "library.cafe@campus.edu", category: "Food" },
    { id: "MOCK_BOOKSTORE", name: "Varsity Book & Stationery", role: "merchant", email: "bookstore@campus.edu", category: "Books" },
    { id: "MOCK_LAUNDRY", name: "Campus Laundry Hall", role: "merchant", email: "laundry@campus.edu", category: "Laundry" }
  ];

  useEffect(() => {
    // Let's fetch some other students or merchants in Firestore for easier peer-to-peer choice
    const fetchUsers = async () => {
      try {
        const q = query(collection(db, "users"), where("uid", "!=", user.uid));
        const querySnapshot = await getDocs(q);
        const list = querySnapshot.docs.map(doc => ({
          id: doc.id,
          name: doc.data().displayName || doc.data().merchantName || "Campus Member",
          role: doc.data().role,
          email: doc.data().email
        }));
        // Merge list with default mocks to make sure choice list is rich
        setRecentRecipients([...list.filter(u => u.role !== "admin"), ...defaultMerchants]);
      } catch (err) {
        console.error("Error fetching target list:", err);
        setRecentRecipients(defaultMerchants);
      }
    };
    fetchUsers();
  }, [user.uid]);

  const selectRecipient = (recipient: typeof recentRecipients[0]) => {
    setTargetId(recipient.id);
    setTargetName(recipient.name);
    // Auto category selection
    if (recipient.role === "merchant") {
      if (recipient.name.includes("Café")) {
        setCategory("Food");
        setDescription("Espresso & pastries checkout");
      } else if (recipient.name.includes("Book") || recipient.name.includes("Stationery")) {
        setCategory("Books");
        setDescription("Semester books & materials");
      } else if (recipient.name.includes("Laundry")) {
        setCategory("Laundry");
        setDescription("Washing & dry lock load");
      } else {
        setCategory("Food");
        setDescription("Campus checkout payment");
      }
    } else {
      setCategory("Other");
      setDescription("Splitting meal/costs");
    }
  };

  const handlePayment = async (e: React.FormEvent) => {
    e.preventDefault();
    const payAmt = parseFloat(amount);
    if (!targetId) {
      setError("Please select a campus merchant or student recipient.");
      return;
    }
    if (isNaN(payAmt) || payAmt <= 0) {
      setError("Please specify a valid payment amount.");
      return;
    }
    if (user.role === "student" && user.balance < payAmt) {
      setError("Insufficient wallet balance. Please add funds to proceed.");
      return;
    }

    setLoading(true);
    setError("");

    try {
      // Execute the balance transfer using a Firestore atomic transaction
      await runTransaction(db, async (transaction) => {
        // Determine sender ref (can be merchant charging or student paying)
        const senderId = user.role === "student" ? user.uid : targetId;
        const receiverId = user.role === "student" ? targetId : user.uid;

        const senderDocRef = doc(db, "users", senderId);
        const receiverDocRef = doc(db, "users", receiverId);

        // Standard mock targets might not exist in db. Let's fetch and check.
        // If a mock recipient user doesn't exist, we skip updating their Firestore doc
        // but log the transaction anyway (so student's balance gets decremented properly).
        let senderBal = 0;
        let isRealSender = false;
        
        // If the current student is paying, then the sender is real (the user)
        if (senderId === user.uid) {
          senderBal = user.balance;
          isRealSender = true;
        } else {
          const sDoc = await transaction.get(senderDocRef);
          if (sDoc.exists()) {
            senderBal = sDoc.data().balance || 0;
            isRealSender = true;
          }
        }

        let receiverBal = 0;
        let isRealReceiver = false;
        const rDoc = await transaction.get(receiverDocRef);
        if (rDoc.exists()) {
          receiverBal = rDoc.data().balance || 0;
          isRealReceiver = true;
        }

        // Enforce balance checks if sender is real
        if (isRealSender && senderBal < payAmt) {
          throw new Error("Target sender has insufficient balance to complete transaction.");
        }

        // Deduct from sender if real
        if (isRealSender) {
          transaction.update(senderDocRef, { balance: senderBal - payAmt });
        }
        // Add to receiver if real
        if (isRealReceiver) {
          transaction.update(receiverDocRef, { balance: receiverBal + payAmt });
        }

        // Create transaction log
        const txRef = collection(db, "transactions");
        const newTx: Omit<Transaction, "id"> = {
          senderId,
          senderName: senderId === user.uid ? user.displayName : targetName,
          receiverId,
          receiverName: receiverId === user.uid ? user.displayName : targetName,
          amount: payAmt,
          type: user.role === "merchant" || targetId.startsWith("MOCK_") ? "merchant_payment" : "peer_transfer",
          category,
          description: description || `Payment between campus members`,
          timestamp: Date.now()
        };

        const newTxDocRef = doc(txRef);
        transaction.set(newTxDocRef, newTx);
      });

      // Update parent user state
      if (user.role === "student") {
        onRefreshUser({ balance: user.balance - payAmt });
      } else {
        onRefreshUser({ balance: user.balance + payAmt });
      }

      setSuccess(true);
      setAmount("");
      setTargetId("");
      setTargetName("");
      setDescription("");
    } catch (err: any) {
      console.error(err);
      setError(err.message || "Failed to process payment. Try again.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-2xl mx-auto space-y-6">
      {/* Header */}
      <div className="flex items-center gap-3">
        <button
          onClick={() => onNavigate("dashboard")}
          className="p-2 hover:bg-slate-100 rounded-lg transition"
        >
          <ArrowLeft className="h-5 w-5 text-slate-600" />
        </button>
        <div>
          <h2 className="text-xl font-bold text-slate-800">Campus Payments</h2>
          <p className="text-xs text-slate-500 font-medium">Scan to pay or receive instant university fund transfers</p>
        </div>
      </div>

      {success ? (
        <div className="bg-white border border-emerald-100 shadow-sm rounded-2xl p-8 text-center space-y-4">
          <div className="inline-flex items-center justify-center h-14 w-14 rounded-full bg-emerald-50 text-emerald-500 mb-2">
            <CheckCircle2 className="h-8 w-8" />
          </div>
          <h3 className="text-xl font-bold text-slate-800">Transaction Complete!</h3>
          <p className="text-slate-500 text-sm max-w-sm mx-auto">
            Payment has been successfully processed and settled onto the campus merchant accounts ledger.
          </p>
          <div className="py-2.5 px-4 bg-slate-50 inline-block rounded-xl border border-slate-100">
            <span className="text-xs font-bold text-slate-400 uppercase tracking-wider block">Remaining Balance</span>
            <span className="text-2xl font-extrabold text-blue-900 mt-1 block">
              ${user.balance.toFixed(2)}
            </span>
          </div>
          <div className="flex gap-2 justify-center pt-2">
            <button
              onClick={() => setSuccess(false)}
              className="py-2 px-4 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs rounded-xl transition"
            >
              Make Another Payment
            </button>
            <button
              onClick={() => onNavigate("dashboard")}
              className="py-2 px-4 bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs rounded-xl shadow-sm transition"
            >
              Go to Dashboard
            </button>
          </div>
        </div>
      ) : (
        <div className="bg-white rounded-2xl border border-slate-100 shadow-sm overflow-hidden">
          {/* Tabs for Students */}
          {user.role === "student" && (
            <div className="flex border-b border-slate-100">
              <button
                onClick={() => {
                  setActiveTab("show_qr");
                  setError("");
                }}
                className={`flex-1 py-3 text-center text-xs font-bold transition flex items-center justify-center gap-1.5 ${
                  activeTab === "show_qr"
                    ? "border-b-2 border-blue-600 text-blue-700 bg-blue-50/25"
                    : "text-slate-500 hover:text-slate-800 hover:bg-slate-50/50"
                }`}
              >
                <QrCode className="h-4 w-4" /> My Student QR Code
              </button>
              <button
                onClick={() => {
                  setActiveTab("pay_peer_merchant");
                  setError("");
                }}
                className={`flex-1 py-3 text-center text-xs font-bold transition flex items-center justify-center gap-1.5 ${
                  activeTab === "pay_peer_merchant"
                    ? "border-b-2 border-blue-600 text-blue-700 bg-blue-50/25"
                    : "text-slate-500 hover:text-slate-800 hover:bg-slate-50/50"
                }`}
              >
                <Send className="h-4 w-4" /> Pay Peer or Merchant
              </button>
            </div>
          )}

          {/* Tab Content: Show QR Code */}
          {activeTab === "show_qr" && user.role === "student" && (
            <div className="p-8 text-center space-y-6 max-w-sm mx-auto">
              <div className="space-y-1.5">
                <span className="text-xs font-bold text-slate-400 uppercase tracking-wider block">Scan At Checkouts</span>
                <span className="text-base font-bold text-slate-800 block">{user.displayName}</span>
                <span className="text-xs text-slate-500 font-medium">Student ID: {user.studentId || "N/A"}</span>
              </div>

              {/* Generative QR Visual (Beautiful CSS Grid / SVG block to represent QR) */}
              <div className="p-4 bg-white border-2 border-slate-100 rounded-3xl inline-block shadow-sm">
                <div className="bg-blue-900 p-3 rounded-2xl">
                  {/* Beautiful visual fake QR Code made of SVG */}
                  <svg className="h-44 w-44 text-white" viewBox="0 0 100 100" fill="currentColor">
                    {/* Corners */}
                    <rect x="0" y="0" width="25" height="25" />
                    <rect x="5" y="5" width="15" height="15" fill="#1e3a8a" />
                    <rect x="75" y="0" width="25" height="25" />
                    <rect x="80" y="5" width="15" height="15" fill="#1e3a8a" />
                    <rect x="0" y="75" width="25" height="25" />
                    <rect x="5" y="80" width="15" height="15" fill="#1e3a8a" />
                    
                    {/* Small inner markers */}
                    <rect x="10" y="10" width="5" height="5" />
                    <rect x="85" y="10" width="5" height="5" />
                    <rect x="10" y="85" width="5" height="5" />
                    
                    {/* Random beautiful QR structures */}
                    <rect x="35" y="5" width="10" height="5" />
                    <rect x="50" y="5" width="5" height="15" />
                    <rect x="60" y="10" width="10" height="5" />
                    <rect x="35" y="20" width="20" height="5" />
                    <rect x="65" y="20" width="5" height="15" />
                    
                    <rect x="5" y="35" width="15" height="5" />
                    <rect x="25" y="35" width="10" height="10" />
                    <rect x="45" y="35" width="5" height="5" />
                    <rect x="55" y="35" width="15" height="10" />
                    <rect x="75" y="35" width="20" height="5" />
                    
                    <rect x="5" y="50" width="5" height="15" />
                    <rect x="15" y="55" width="15" height="5" />
                    <rect x="35" y="50" width="25" height="5" />
                    <rect x="65" y="55" width="5" height="15" />
                    <rect x="75" y="50" width="10" height="10" />
                    
                    <rect x="35" y="65" width="10" height="5" />
                    <rect x="55" y="65" width="5" height="20" />
                    <rect x="65" y="75" width="15" height="5" />
                    <rect x="85" y="75" width="10" height="10" />
                    <rect x="35" y="80" width="15" height="5" />
                    <rect x="70" y="85" width="10" height="5" />
                  </svg>
                </div>
              </div>

              <div className="bg-slate-50 p-3.5 rounded-2xl border border-slate-100 text-left">
                <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block mb-1">Your balance</span>
                <div className="flex justify-between items-center">
                  <span className="text-xl font-extrabold text-blue-900">${user.balance.toFixed(2)}</span>
                  <button
                    onClick={() => onNavigate("add-money")}
                    className="text-xs font-bold text-blue-600 hover:text-blue-800"
                  >
                    + Add Funds
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* Tab Content: Pay Peer or Merchant */}
          {activeTab === "pay_peer_merchant" && (
            <div className="p-6 grid grid-cols-1 md:grid-cols-5 gap-6">
              {/* Recipient Selection list */}
              <div className="md:col-span-2 space-y-3">
                <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">Select Campus Contact</span>
                <div className="space-y-2 max-h-[300px] overflow-y-auto pr-1">
                  {recentRecipients.map((recipient) => (
                    <button
                      key={recipient.id}
                      type="button"
                      onClick={() => selectRecipient(recipient)}
                      className={`w-full text-left p-3 border rounded-xl transition flex items-center justify-between ${
                        targetId === recipient.id
                          ? "bg-blue-50 border-blue-500 text-blue-950 shadow-sm"
                          : "bg-white border-slate-100 text-slate-700 hover:bg-slate-50"
                      }`}
                    >
                      <div className="flex items-center gap-2">
                        {recipient.role === "merchant" ? (
                          <div className="p-1.5 rounded-lg bg-emerald-50 border border-emerald-100 text-emerald-600">
                            <Coffee className="h-3.5 w-3.5" />
                          </div>
                        ) : (
                          <div className="p-1.5 rounded-lg bg-purple-50 border border-purple-100 text-purple-600">
                            <User className="h-3.5 w-3.5" />
                          </div>
                        )}
                        <div>
                          <span className="text-xs font-bold block">{recipient.name}</span>
                          <span className="text-[10px] text-slate-400 font-medium block truncate max-w-[120px]">{recipient.email}</span>
                        </div>
                      </div>
                      <span className="text-[9px] font-extrabold uppercase px-1.5 py-0.5 rounded-full bg-slate-100 text-slate-500">
                        {recipient.role}
                      </span>
                    </button>
                  ))}
                </div>
              </div>

              {/* Form Input Block */}
              <div className="md:col-span-3 space-y-4">
                {error && (
                  <div className="bg-rose-50 border border-rose-100 text-rose-700 text-xs p-3 rounded-xl font-semibold">
                    {error}
                  </div>
                )}

                <form onSubmit={handlePayment} className="space-y-4">
                  <div>
                    <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1">
                      Recipient
                    </label>
                    <input
                      type="text"
                      required
                      disabled
                      value={targetName ? `${targetName} (${targetId})` : "Please select a contact from the left list..."}
                      className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-slate-900 font-semibold focus:outline-none text-xs"
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label htmlFor="payment-amount" className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1">
                        Amount ($)
                      </label>
                      <input
                        id="payment-amount"
                        type="number"
                        step="0.01"
                        min="0.1"
                        required
                        placeholder="0.00"
                        value={amount}
                        onChange={(e) => setAmount(e.target.value)}
                        className="w-full px-3 py-2 border border-slate-200 rounded-xl text-slate-900 font-bold focus:outline-none focus:ring-2 focus:ring-blue-600 text-sm"
                      />
                    </div>

                    <div>
                      <label htmlFor="payment-category" className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1">
                        Category
                      </label>
                      <select
                        id="payment-category"
                        value={category}
                        onChange={(e) => setCategory(e.target.value)}
                        className="w-full px-3 py-2 border border-slate-200 rounded-xl text-slate-900 font-semibold focus:outline-none focus:ring-2 focus:ring-blue-600 text-sm"
                      >
                        <option value="Food">Food & Dining</option>
                        <option value="Books">Books & Materials</option>
                        <option value="Laundry">Laundry & Lockers</option>
                        <option value="Entertainment">Entertainment</option>
                        <option value="Transport">Travel & Transport</option>
                        <option value="Other">Other Miscellaneous</option>
                      </select>
                    </div>
                  </div>

                  <div>
                    <label htmlFor="payment-desc" className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1">
                      Add a Memo
                    </label>
                    <input
                      id="payment-desc"
                      type="text"
                      required
                      placeholder="e.g. Split lunch / Coffee purchase"
                      value={description}
                      onChange={(e) => setDescription(e.target.value)}
                      className="w-full px-3 py-2 border border-slate-200 rounded-xl text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-600 text-xs"
                    />
                  </div>

                  <button
                    type="submit"
                    disabled={loading || !targetId}
                    className="w-full py-3 bg-blue-600 hover:bg-blue-700 text-white font-bold text-sm rounded-xl shadow-sm transition flex items-center justify-center gap-2 disabled:opacity-50"
                  >
                    {loading ? (
                      <>
                        <Loader2 className="h-4 w-4 animate-spin" /> Authorizing Payment...
                      </>
                    ) : (
                      "Authorize Instant Payment"
                    )}
                  </button>
                </form>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
