import React, { useState, useEffect } from "react";
import { CampusUser, Transaction } from "../types";
import { db } from "../firebase";
import { collection, query, getDocs, doc, runTransaction, onSnapshot, getDoc } from "firebase/firestore";
import { 
  ArrowLeft, 
  ShieldAlert, 
  Users, 
  TrendingUp, 
  Coins, 
  Loader2, 
  CheckCircle2, 
  Coffee, 
  Activity, 
  Send,
  AlertTriangle,
  History
} from "lucide-react";

interface AdminScreenProps {
  user: CampusUser;
  onNavigate: (page: string) => void;
}

export default function AdminScreen({ user, onNavigate }: AdminScreenProps) {
  const [users, setUsers] = useState<CampusUser[]>([]);
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [loading, setLoading] = useState(true);
  const [targetStudentId, setTargetStudentId] = useState("");
  const [grantAmount, setGrantAmount] = useState("");
  const [grantReason, setGrantReason] = useState("Semester Hardship stipend assistance");
  const [grantLoading, setGrantLoading] = useState(false);
  const [grantSuccess, setGrantSuccess] = useState(false);
  const [error, setError] = useState("");

  useEffect(() => {
    // Listen to all users and transactions
    const unsubUsers = onSnapshot(collection(db, "users"), (snapshot) => {
      const uList = snapshot.docs.map(doc => ({ uid: doc.id, ...doc.data() }) as CampusUser);
      setUsers(uList);
    });

    const unsubTxs = onSnapshot(collection(db, "transactions"), (snapshot) => {
      const tList = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }) as Transaction)
        .sort((a, b) => b.timestamp - a.timestamp);
      setTransactions(tList);
      setLoading(false);
    });

    return () => {
      unsubUsers();
      unsubTxs();
    };
  }, []);

  // Compute analytics
  const totalStudents = users.filter(u => u.role === "student").length;
  const totalMerchants = users.filter(u => u.role === "merchant").length;
  const totalStudentBalances = users.filter(u => u.role === "student").reduce((sum, u) => sum + (u.balance || 0), 0);
  const totalSystemTransactions = transactions.reduce((sum, t) => sum + t.amount, 0);

  const handleGrantAid = async (e: React.FormEvent) => {
    e.preventDefault();
    const grantAmt = parseFloat(grantAmount);
    if (!targetStudentId) {
      setError("Please select a student wallet to receive aid.");
      return;
    }
    if (isNaN(grantAmt) || grantAmt <= 0) {
      setError("Please specify a valid grant amount.");
      return;
    }

    setGrantLoading(true);
    setError("");

    try {
      const studentRef = doc(db, "users", targetStudentId);
      
      await runTransaction(db, async (transaction) => {
        const studentDoc = await transaction.get(studentRef);
        if (!studentDoc.exists()) {
          throw new Error("Target student does not exist.");
        }

        const currentBal = studentDoc.data().balance || 0;
        const studentName = studentDoc.data().displayName || "Student";
        
        // Add balance
        transaction.update(studentRef, { balance: currentBal + grantAmt });

        // Insert Transaction Log
        const txRef = collection(db, "transactions");
        const newTx: Omit<Transaction, "id"> = {
          senderId: "admin_treasury",
          senderName: "University Treasury Core",
          receiverId: targetStudentId,
          receiverName: studentName,
          amount: grantAmt,
          type: "admin_grant",
          category: "Deposits",
          description: grantReason || "Emergency Academic Stipend",
          timestamp: Date.now()
        };

        const newTxDocRef = doc(txRef);
        transaction.set(newTxDocRef, newTx);
      });

      setGrantSuccess(true);
      setGrantAmount("");
      setTimeout(() => setGrantSuccess(false), 4000);
    } catch (err: any) {
      console.error(err);
      setError(err.message || "Failed to process emergency aid.");
    } finally {
      setGrantLoading(false);
    }
  };

  return (
    <div className="max-w-5xl mx-auto space-y-6">
      {/* Header */}
      <div className="flex items-center gap-3">
        <button
          onClick={() => onNavigate("dashboard")}
          className="p-2 hover:bg-slate-100 rounded-lg transition"
        >
          <ArrowLeft className="h-5 w-5 text-slate-600" />
        </button>
        <div>
          <h2 className="text-xl font-bold text-slate-800">University Operations Control</h2>
          <p className="text-xs text-slate-500 font-medium">Deans administrative gateway for wallet audit, treasury checks, and student aid issuance</p>
        </div>
      </div>

      {/* Admin stats widgets */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white p-5 rounded-2xl border border-slate-100 shadow-sm">
          <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">Registered Students</span>
          <div className="flex items-center justify-between mt-2">
            <span className="text-2xl font-extrabold text-blue-900">{totalStudents}</span>
            <Users className="h-5 w-5 text-blue-600" />
          </div>
          <p className="text-[10px] text-slate-400 mt-1 font-semibold">Active student smart-cards</p>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-slate-100 shadow-sm">
          <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">Student Balances</span>
          <div className="flex items-center justify-between mt-2">
            <span className="text-2xl font-extrabold text-blue-900">${totalStudentBalances.toFixed(2)}</span>
            <Coins className="h-5 w-5 text-amber-500" />
          </div>
          <p className="text-[10px] text-slate-400 mt-1 font-semibold">Total active student treasury</p>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-slate-100 shadow-sm">
          <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">Affiliated Outlets</span>
          <div className="flex items-center justify-between mt-2">
            <span className="text-2xl font-extrabold text-blue-900">{totalMerchants}</span>
            <Coffee className="h-5 w-5 text-emerald-600" />
          </div>
          <p className="text-[10px] text-slate-400 mt-1 font-semibold">Campus checkout points active</p>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-slate-100 shadow-sm">
          <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">Total System Volume</span>
          <div className="flex items-center justify-between mt-2">
            <span className="text-2xl font-extrabold text-blue-900">${totalSystemTransactions.toFixed(2)}</span>
            <TrendingUp className="h-5 w-5 text-purple-600" />
          </div>
          <p className="text-[10px] text-slate-400 mt-1 font-semibold">Sum of all loaded/spent funds</p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-5 gap-6">
        {/* Left column: Aid allocation and user list */}
        <div className="lg:col-span-2 space-y-6">
          {/* Grant Emergency Aid */}
          <div className="bg-white p-6 rounded-2xl border border-slate-100 shadow-sm space-y-4">
            <div className="flex items-center gap-2">
              <ShieldAlert className="h-5 w-5 text-purple-600" />
              <span className="text-xs font-bold text-slate-800">Issue Emergency Student Grant</span>
            </div>

            {error && (
              <div className="bg-rose-50 border border-rose-100 text-rose-700 text-xs p-3 rounded-xl font-semibold">
                {error}
              </div>
            )}

            {grantSuccess && (
              <div className="bg-emerald-50 border border-emerald-100 text-emerald-700 text-xs p-3 rounded-xl font-bold flex items-center gap-1.5">
                <CheckCircle2 className="h-4 w-4" /> Emergency hard-cash grant sent securely!
              </div>
            )}

            <form onSubmit={handleGrantAid} className="space-y-3">
              <div>
                <label htmlFor="target-student" className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1">
                  Recipient Student
                </label>
                <select
                  id="target-student"
                  value={targetStudentId}
                  onChange={(e) => setTargetStudentId(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-200 bg-white rounded-xl text-xs text-slate-700 font-semibold focus:outline-none"
                >
                  <option value="">Select Student...</option>
                  {users.filter(u => u.role === "student").map(u => (
                    <option key={u.uid} value={u.uid}>
                      {u.displayName} ({u.studentId || "No ID"}) - Bal: ${u.balance.toFixed(2)}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label htmlFor="grant-amount" className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1">
                  Aid Amount ($)
                </label>
                <input
                  id="grant-amount"
                  type="number"
                  step="0.01"
                  min="1"
                  required
                  placeholder="0.00"
                  value={grantAmount}
                  onChange={(e) => setGrantAmount(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-200 rounded-xl text-slate-900 font-bold focus:outline-none text-xs"
                />
              </div>

              <div>
                <label htmlFor="grant-reason" className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1">
                  Official Ledger memo
                </label>
                <input
                  id="grant-reason"
                  type="text"
                  required
                  placeholder="e.g. Textbook hard-ship support"
                  value={grantReason}
                  onChange={(e) => setGrantReason(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-200 rounded-xl text-slate-950 focus:outline-none text-xs"
                />
              </div>

              <button
                type="submit"
                disabled={grantLoading || !targetStudentId}
                className="w-full py-2 bg-purple-600 hover:bg-purple-700 text-white font-bold text-xs rounded-xl shadow-sm transition flex items-center justify-center gap-1.5"
              >
                {grantLoading ? (
                  <Loader2 className="h-4 w-4 animate-spin" />
                ) : (
                  <>
                    <Send className="h-3.5 w-3.5" /> Allocate Emergency Funds
                  </>
                )}
              </button>
            </form>
          </div>

          {/* Registered Accounts list */}
          <div className="bg-white p-6 rounded-2xl border border-slate-100 shadow-sm space-y-4">
            <span className="text-xs font-bold text-slate-800 block">Registered University Accounts</span>
            <div className="space-y-2 max-h-[220px] overflow-y-auto pr-1 divide-y divide-slate-100">
              {users.map((u) => (
                <div key={u.uid} className="pt-2.5 flex justify-between items-center text-xs">
                  <div>
                    <span className="font-bold text-slate-800 block">{u.displayName || u.merchantName}</span>
                    <span className="text-[10px] text-slate-400 capitalize font-medium">{u.role} • {u.email}</span>
                  </div>
                  <span className="font-bold text-blue-900">${u.balance.toFixed(2)}</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Right column: Ledger Auditor audit trail */}
        <div className="lg:col-span-3 bg-white p-6 rounded-2xl border border-slate-100 shadow-sm space-y-4 flex flex-col">
          <div className="flex justify-between items-center">
            <div className="flex items-center gap-2">
              <History className="h-5 w-5 text-blue-600" />
              <span className="text-xs font-bold text-slate-800">System Audit Trail Ledger</span>
            </div>
            <span className="text-[9px] font-extrabold uppercase px-1.5 py-0.5 rounded bg-blue-100 text-blue-700 animate-pulse">Live Feed</span>
          </div>

          {loading ? (
            <div className="py-12 text-center text-slate-400 font-semibold text-xs">
              Fetching ledger journals...
            </div>
          ) : transactions.length === 0 ? (
            <div className="py-16 text-center">
              <p className="text-xs font-bold text-slate-400">No transactions recorded in system database.</p>
            </div>
          ) : (
            <div className="overflow-y-auto max-h-[500px] flex-1 divide-y divide-slate-100 pr-1">
              {transactions.map((tx) => (
                <div key={tx.id} className="py-3 flex justify-between items-center text-xs">
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-slate-800">{tx.senderName}</span>
                      <span className="text-slate-400">→</span>
                      <span className="font-bold text-slate-800">{tx.receiverName}</span>
                    </div>
                    <span className="text-[10px] font-semibold text-slate-500 block mt-1">{tx.description}</span>
                    <span className="text-[9px] text-slate-400 block mt-0.5">{new Date(tx.timestamp).toLocaleString()} • {tx.category}</span>
                  </div>
                  <span className="font-extrabold text-slate-800 shrink-0 ml-4">${tx.amount.toFixed(2)}</span>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
