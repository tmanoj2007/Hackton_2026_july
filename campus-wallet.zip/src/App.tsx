import React, { useState, useEffect } from "react";
import { CampusUser } from "./types";
import { auth, db } from "./firebase";
import { onAuthStateChanged, signOut } from "firebase/auth";
import { doc, onSnapshot } from "firebase/firestore";
import { motion, AnimatePresence } from "motion/react";

// Components
import LoginScreen from "./components/LoginScreen";
import DashboardScreen from "./components/DashboardScreen";
import WalletScreen from "./components/WalletScreen";
import PaymentScreen from "./components/PaymentScreen";
import HistoryScreen from "./components/HistoryScreen";
import TipsScreen from "./components/TipsScreen";
import AdminScreen from "./components/AdminScreen";

// Icons
import { 
  Wallet, 
  Home, 
  CreditCard, 
  QrCode, 
  History, 
  Sparkles, 
  ShieldAlert, 
  LogOut,
  Menu,
  X
} from "lucide-react";

export default function App() {
  const [currentUser, setCurrentUser] = useState<CampusUser | null>(null);
  const [authLoading, setAuthLoading] = useState(true);
  const [currentPage, setCurrentPage] = useState<string>("dashboard");
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  // Listen for real-time authentication states
  useEffect(() => {
    const unsubscribeAuth = onAuthStateChanged(auth, (authUser) => {
      if (authUser) {
        // Authenticated! Now set up a real-time listener for the Firestore user document
        const userDocRef = doc(db, "users", authUser.uid);
        const unsubscribeUser = onSnapshot(userDocRef, (snapshot) => {
          if (snapshot.exists()) {
            setCurrentUser(snapshot.data() as CampusUser);
          } else {
            console.warn("User document not found in Firestore for UID:", authUser.uid);
          }
          setAuthLoading(false);
        }, (err) => {
          console.error("Firestore snapshot error:", err);
          setAuthLoading(false);
        });

        return () => unsubscribeUser();
      } else {
        setCurrentUser(null);
        setAuthLoading(false);
      }
    });

    return () => unsubscribeAuth();
  }, []);

  const handleLogout = async () => {
    try {
      await signOut(auth);
      setCurrentUser(null);
      setCurrentPage("dashboard");
    } catch (err) {
      console.error("Logout failed:", err);
    }
  };

  const handleRefreshUser = (updatedUser: Partial<CampusUser>) => {
    if (currentUser) {
      setCurrentUser({ ...currentUser, ...updatedUser } as CampusUser);
    }
  };

  const renderActivePage = () => {
    if (!currentUser) return null;

    switch (currentPage) {
      case "dashboard":
        return <DashboardScreen user={currentUser} onNavigate={setCurrentPage} />;
      case "add-money":
        return (
          <WalletScreen 
            user={currentUser} 
            onRefreshUser={handleRefreshUser} 
            onNavigate={setCurrentPage} 
          />
        );
      case "qr-payment":
        return (
          <PaymentScreen 
            user={currentUser} 
            onRefreshUser={handleRefreshUser} 
            onNavigate={setCurrentPage} 
          />
        );
      case "history":
        return <HistoryScreen user={currentUser} onNavigate={setCurrentPage} />;
      case "ai-tips":
        return (
          <TipsScreen 
            user={currentUser} 
            onRefreshUser={handleRefreshUser} 
            onNavigate={setCurrentPage} 
          />
        );
      case "admin":
        if (currentUser.role !== "admin") {
          setCurrentPage("dashboard");
          return null;
        }
        return <AdminScreen user={currentUser} onNavigate={setCurrentPage} />;
      default:
        return <DashboardScreen user={currentUser} onNavigate={setCurrentPage} />;
    }
  };

  if (authLoading) {
    return (
      <div className="min-h-screen bg-slate-50 flex flex-col justify-center items-center gap-3">
        <div className="inline-flex items-center justify-center h-12 w-12 rounded-full bg-blue-600 text-white shadow-md">
          <Wallet className="h-6 w-6 animate-pulse" />
        </div>
        <span className="text-xs font-bold text-slate-500 uppercase tracking-widest animate-pulse">
          Syncing University Pass...
        </span>
      </div>
    );
  }

  if (!currentUser) {
    return (
      <LoginScreen onLoginSuccess={(user) => {
        setCurrentUser(user);
        setCurrentPage("dashboard");
      }} />
    );
  }

  const menuItems = [
    { id: "dashboard", label: "Dashboard", icon: Home },
    { id: "add-money", label: "Add Money", icon: CreditCard },
    { id: "qr-payment", label: "QR Payments", icon: QrCode },
    { id: "history", label: "Account Statement", icon: History },
    { id: "ai-tips", label: "AI Spending Tips", icon: Sparkles },
    ...(currentUser.role === "admin" ? [{ id: "admin", label: "Dean Control", icon: ShieldAlert }] : []),
  ];

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col font-sans text-slate-900">
      {/* Top University Branding Header */}
      <header className="bg-white border-b border-slate-100 sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="h-9 w-9 rounded-xl bg-blue-600 text-white flex items-center justify-center shadow-sm">
              <Wallet className="h-5 w-5" />
            </div>
            <div>
              <span className="text-sm font-extrabold text-blue-900 tracking-tight block">BlueRidge State</span>
              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block -mt-0.5">Campus Wallet</span>
            </div>
          </div>

          {/* Desktop Navigation */}
          <nav className="hidden lg:flex items-center gap-1">
            {menuItems.map((item) => {
              const Icon = item.icon;
              const isActive = currentPage === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => setCurrentPage(item.id)}
                  className={`py-1.5 px-3 rounded-lg text-xs font-bold transition flex items-center gap-1.5 ${
                    isActive 
                      ? "bg-blue-50 text-blue-700" 
                      : "text-slate-600 hover:text-slate-900 hover:bg-slate-50"
                  }`}
                >
                  <Icon className={`h-4 w-4 ${isActive ? "text-blue-600" : "text-slate-400"}`} />
                  {item.label}
                </button>
              );
            })}
          </nav>

          {/* Right Header Controls */}
          <div className="flex items-center gap-3">
            <div className="hidden sm:block text-right">
              <span className="text-xs font-bold text-slate-800 block leading-tight">{currentUser.displayName}</span>
              <span className="text-[10px] font-semibold text-slate-400 block capitalize leading-none mt-0.5">
                {currentUser.role === "merchant" ? "Outlet Merchant" : `${currentUser.role}`}
              </span>
            </div>

            <button
              onClick={handleLogout}
              className="p-2 hover:bg-slate-100 rounded-lg text-slate-400 hover:text-slate-700 transition"
              title="Logout from Campus Wallet"
            >
              <LogOut className="h-5 w-5" />
            </button>

            {/* Mobile menu trigger */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="lg:hidden p-2 hover:bg-slate-100 rounded-lg text-slate-600 transition"
            >
              {mobileMenuOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
            </button>
          </div>
        </div>
      </header>

      {/* Mobile Drawer Navigation */}
      <AnimatePresence>
        {mobileMenuOpen && (
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            className="lg:hidden bg-white border-b border-slate-100 px-4 py-3 space-y-1 sticky top-16 z-30 shadow-sm"
          >
            {menuItems.map((item) => {
              const Icon = item.icon;
              const isActive = currentPage === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => {
                    setCurrentPage(item.id);
                    setMobileMenuOpen(false);
                  }}
                  className={`w-full py-2.5 px-3 rounded-xl text-xs font-bold transition flex items-center gap-2.5 ${
                    isActive 
                      ? "bg-blue-50 text-blue-700" 
                      : "text-slate-600 hover:text-slate-900 hover:bg-slate-50"
                  }`}
                >
                  <Icon className={`h-4.5 w-4.5 ${isActive ? "text-blue-600" : "text-slate-400"}`} />
                  {item.label}
                </button>
              );
            })}
          </motion.div>
        )}
      </AnimatePresence>

      {/* Main Workspace Frame */}
      <main className="flex-grow max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <AnimatePresence mode="wait">
          <motion.div
            key={currentPage}
            initial={{ opacity: 0, y: 4 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -4 }}
            transition={{ duration: 0.15 }}
          >
            {renderActivePage()}
          </motion.div>
        </AnimatePresence>
      </main>

      {/* Subtle Footer */}
      <footer className="bg-white border-t border-slate-100 py-6 mt-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center space-y-1.5">
          <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">
            BlueRidge State University Smart Card & Finance Systems
          </p>
          <p className="text-[10px] text-slate-400">
            Secure ledger technology powered by Firebase & cloud operations. Late-session audit logs recorded.
          </p>
        </div>
      </footer>
    </div>
  );
}
