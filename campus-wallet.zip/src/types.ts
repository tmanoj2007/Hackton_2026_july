export type UserRole = "student" | "merchant" | "admin";

export interface CampusUser {
  uid: string;
  email: string;
  displayName: string;
  role: UserRole;
  balance: number;
  studentId?: string; // For students
  merchantName?: string; // For merchants
  createdAt: number;
}

export type TransactionType = "peer_transfer" | "merchant_payment" | "add_money" | "admin_grant";

export interface Transaction {
  id: string;
  senderId: string;
  senderName: string;
  receiverId: string;
  receiverName: string;
  amount: number;
  type: TransactionType;
  category: string;
  description: string;
  timestamp: number; // UTC timestamp
}

export interface SpendingTip {
  title: string;
  tip: string;
  category: string;
  impact: "low" | "medium" | "high";
}

export interface CampusMerchant {
  id: string;
  name: string;
  category: string;
  location: string;
  isActive: boolean;
}
